function vectorModify(handle, values)

% VECTORMODIFY Helper code for visualisation of vectorial data.

set(handle, 'YData', values);
